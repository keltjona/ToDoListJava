/**
 * 
 */
/**
 * 
 */
module ToDoListApplication {
requires java.desktop;
}
