package classes;
public class App {
    public static void main(String[] args) {
        new ToDoListGui().setVisible(true);
    }
}
